/** @type {import('next').NextConfig} */

const nextConfig = {
  env:{
    Base_URL:process.env.BaseUrl
  }
};

export default nextConfig;
