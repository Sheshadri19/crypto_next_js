export interface rateall {
    data: Daum[]
    timestamp: number
  }
  
  export interface Daum {
    id: string
    symbol: string
    currencySymbol?: string
    type: string
    rateUsd: string
  }
  