
export interface historySlug {
    data: Daum[]
    timestamp: number
  }
  
  export interface Daum {
    priceUsd: string
    time: number
    date:string
  }
  