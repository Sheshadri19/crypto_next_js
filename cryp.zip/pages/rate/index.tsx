
import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { Endpoint } from '../api/Endpoint';
import { axiosInstance } from '@/Service/AxiosInstance';
import { rateall } from '@/TypeScript/rateallinterface';

const index = () => {

  const {isLoading,error,data}=useQuery({
    queryKey:['ratedata'],
    queryFn:async()=>{
      const data=await axiosInstance.get<rateall>(
        Endpoint.pageEndpoint.exchanged
      )
  
      console.log("rateall",data.data);
      return data.data
      
    }
  })


  return (
    <div>
      {
        data?.data?.map((item)=>{
          return (
            <>
             <h1>{item.currencySymbol}</h1>
            </>
          )
        })
      }
     
    </div>
  )
}

export default index
